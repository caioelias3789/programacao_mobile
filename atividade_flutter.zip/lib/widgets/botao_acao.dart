import 'package:flutter/material.dart';

class BotaoAcao extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isRating;
  final VoidCallback onTap;

  const BotaoAcao({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
    this.isRating = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          isRating
              ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(Icons.star, color: Colors.blue, size: 16),
                    Icon(Icons.star, color: Colors.blue, size: 16),
                    Icon(Icons.star, color: Colors.blue, size: 16),
                  ],
                )
              : Icon(
                  icon,
                  color: Colors.blue,
                  size: 22,
                ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              color: Colors.blue,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
