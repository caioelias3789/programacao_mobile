import 'package:flutter/material.dart';

class JaFuiPage extends StatelessWidget {
  const JaFuiPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Já Fui'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Lugares que já visitei',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.check_circle,
                  color: Colors.green,
                ),
                title: const Text('Praia de Tambaú'),
                subtitle: const Text('João Pessoa, Brasil'),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.check_circle,
                  color: Colors.green,
                ),
                title: const Text('Praia de Copacabana'),
                subtitle: const Text('Rio de Janeiro, Brasil'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
