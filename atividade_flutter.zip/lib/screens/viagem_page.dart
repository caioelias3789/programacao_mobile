import 'package:flutter/material.dart';
import '../widgets/botao_acao.dart';
import 'quero_ir_page.dart';
import 'ja_fui_page.dart';
import 'compartilhar_page.dart';
import 'avaliacoes_page.dart';
import '../screens_pessoas/lucas_page.dart';
import '../screens_pessoas/mariana_page.dart';
import '../screens_pessoas/gabriel_page.dart';
import '../screens_pessoas/ana_page.dart';

class ViagemPage extends StatelessWidget {
  const ViagemPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Viagens'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Image.asset(
                  'assets/coliseu-9.jpg',
                  width: double.infinity,
                  height: 250,
                  fit: BoxFit.cover,
                ),
                Container(
                  width: double.infinity,
                  height: 250,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withValues(alpha: 0.7),
                      ],
                    ),
                  ),
                ),
                const Positioned(
                  left: 20,
                  bottom: 35,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Roma',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                        ),
                      ),
                      Text(
                        'Coliseu',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 25),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                BotaoAcao(
                  icon: Icons.favorite_border,
                  label: 'Quero Ir',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const QueroIrPage(),
                      ),
                    );
                  },
                ),
                BotaoAcao(
                  icon: Icons.check_circle_outline,
                  label: 'Já Fui',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const JaFuiPage(),
                      ),
                    );
                  },
                ),
                BotaoAcao(
                  icon: Icons.share,
                  label: 'Compartilhar',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const CompartilharPage(),
                      ),
                    );
                  },
                ),
                BotaoAcao(
                  icon: Icons.star,
                  label: 'Avaliações',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const AvaliacoesPage(),
                      ),
                    );
                  },
                ),
              ],
            ),

            const SizedBox(height: 30),

            const Padding(
              padding: EdgeInsets.all(20),
              child: Text(
                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce id '
                'diam id ligula ultricies pulvinar. In neque lectus, sagittis eu libero '
                'et, venenatis lacinia nulla. Etiam eget purus ico. Nam '
                'consectetur ornare est eu lobortis. Morbi eu augue eu lectus '
                'condimentum vestibulum. Etiam id nibh luctus, porttitor arcu et, '
                'porttitor purus. Pellentesque vulputate nibh sit amet rutrum '
                'viverra. Nullam eget metus est. Integer condimentum, odio sed '
                'congue malesuada, ipsum nisl bibendum lectus, quis porttitor '
                'ante lacus in mi. Curabitur eget imperdiet ante. Aliquam magna '
                'tortor, volutpat sit amet mi a, cursus malesuada leo. Aenean '
                'dolor erat, gravida ut ultricies sec, convallis nec ipsum.',
                style: TextStyle(
                  fontSize: 16,
                  height: 1.5,
                ),
                textAlign: TextAlign.justify,
              ),
            ),

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Pessoas Encontradas',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Filtrar',
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Avatares com navegação para as páginas individuais
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const LucasPage(),
                      ),
                    );
                  },
                  child: criarAvatar(
                    'https://randomuser.me/api/portraits/men/32.jpg',
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const MarianaPage(),
                      ),
                    );
                  },
                  child: criarAvatar(
                    'https://randomuser.me/api/portraits/women/44.jpg',
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const GabrielPage(),
                      ),
                    );
                  },
                  child: criarAvatar(
                    'https://randomuser.me/api/portraits/men/75.jpg',
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const AnaPage(),
                      ),
                    );
                  },
                  child: criarAvatar(
                    'https://randomuser.me/api/portraits/women/68.jpg',
                  ),
                ),
              ],
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}

Widget criarAvatar(String imagem) {
  return CircleAvatar(
    radius: 30,
    backgroundColor: Colors.grey,
    child: ClipOval(
      child: Image.network(
        imagem,
        width: 60,
        height: 60,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) {
          return const Icon(Icons.person, size: 35);
        },
      ),
    ),
  );
}
