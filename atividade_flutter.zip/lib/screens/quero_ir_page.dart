import 'package:flutter/material.dart';

class QueroIrPage extends StatelessWidget {
  const QueroIrPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quero Ir'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Lugares que quero conhecer',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.location_on,
                  color: Colors.blue,
                ),
                title: const Text('Coliseu'),
                subtitle: const Text('Roma, Itália'),
                trailing: const Icon(Icons.favorite, color: Colors.red),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.location_on,
                  color: Colors.blue,
                ),
                title: const Text('Torre Eiffel'),
                subtitle: const Text('Paris, França'),
                trailing: const Icon(Icons.favorite, color: Colors.red),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.location_on,
                  color: Colors.blue,
                ),
                title: const Text('Cristo Redentor'),
                subtitle: const Text('Rio de Janeiro, Brasil'),
                trailing: const Icon(Icons.favorite, color: Colors.red),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
