import 'package:flutter/material.dart';

class MarianaPage extends StatelessWidget {
  const MarianaPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Perfil de Mariana'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 65,
                backgroundImage: NetworkImage(
                  'https://randomuser.me/api/portraits/women/44.jpg',
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Mariana, 22 anos',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              const Text('Rio de Janeiro, Brasil'),
              const SizedBox(height: 25),
              const Text(
                'Sou apaixonada por fotografia, viagens '
                'e gastronomia. Adoro registrar momentos '
                'especiais durante minhas viagens.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, height: 1.5),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
