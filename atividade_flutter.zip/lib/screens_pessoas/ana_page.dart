import 'package:flutter/material.dart';

class AnaPage extends StatelessWidget {
  const AnaPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Perfil de Ana'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 65,
                backgroundImage: NetworkImage(
                  'https://randomuser.me/api/portraits/women/68.jpg',
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Ana, 23 anos',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              const Text('Curitiba, Brasil'),
              const SizedBox(height: 25),
              const Text(
                'Gosto de aventuras, natureza e conhecer '
                'novos destinos. Meu sonho é viajar pelo mundo.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, height: 1.5),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
